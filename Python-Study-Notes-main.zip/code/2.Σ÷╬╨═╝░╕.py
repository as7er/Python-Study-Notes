import turtle

t = turtle. Pen()

for x in range(360):

    t. forward(x)

    t. left(58)
